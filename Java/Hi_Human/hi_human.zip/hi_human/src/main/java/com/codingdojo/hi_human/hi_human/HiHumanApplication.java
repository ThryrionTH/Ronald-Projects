package com.codingdojo.hi_human.hi_human;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiHumanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiHumanApplication.class, args);
	}

}
