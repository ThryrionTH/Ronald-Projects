package com.codingdojo.hi_human.hi_human;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiHumanApplicationTests {

	@Test
	void contextLoads() {
	}

}
