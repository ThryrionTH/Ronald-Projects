package com.ronaldceballos.driverlicense.driverlicense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverlicenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
