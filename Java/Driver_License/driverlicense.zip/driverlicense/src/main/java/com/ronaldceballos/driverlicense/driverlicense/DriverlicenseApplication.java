package com.ronaldceballos.driverlicense.driverlicense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverlicenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverlicenseApplication.class, args);
	}

}
