package com.codingdojo.ninjagold.ninjagold;

public class Ninja {
    private int gold;

    public Ninja(int gold) {
        this.gold = gold;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }
}
