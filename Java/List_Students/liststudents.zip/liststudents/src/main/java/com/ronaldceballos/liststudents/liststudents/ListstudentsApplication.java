package com.ronaldceballos.liststudents.liststudents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListstudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListstudentsApplication.class, args);
	}

}
