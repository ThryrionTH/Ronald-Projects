package com.codingdojo.date_time.date_time;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DateTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
