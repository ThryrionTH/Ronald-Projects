package com.codingdojo.date_time.date_time;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DateTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DateTimeApplication.class, args);
	}

}
