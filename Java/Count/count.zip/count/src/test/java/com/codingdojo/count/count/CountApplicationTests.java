package com.codingdojo.count.count;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountApplicationTests {

	@Test
	void contextLoads() {
	}

}
