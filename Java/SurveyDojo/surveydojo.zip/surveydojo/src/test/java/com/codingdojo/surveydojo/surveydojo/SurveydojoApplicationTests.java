package com.codingdojo.surveydojo.surveydojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveydojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
