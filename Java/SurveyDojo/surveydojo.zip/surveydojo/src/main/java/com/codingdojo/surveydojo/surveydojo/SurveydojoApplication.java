package com.codingdojo.surveydojo.surveydojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveydojoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveydojoApplication.class, args);
	}

}
