package com.ronaldceballos.update_delete.update_delete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UpdateDeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
