package com.ronaldceballos.controllersviews.controllersviews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllersviewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
