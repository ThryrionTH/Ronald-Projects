package com.ronaldceballos.controllersviews.controllersviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllersviewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllersviewsApplication.class, args);
	}

}
